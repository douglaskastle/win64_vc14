
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.11.0'
version = '1.11.0'
full_version = '1.11.0'
git_revision = 'Unknown'
release = True

if not release:
    version = full_version
